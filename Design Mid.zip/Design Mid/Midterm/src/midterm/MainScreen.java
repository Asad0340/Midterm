/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package midterm;

import java.util.List;

/**
 *
 * @author Asad
 */
class MainScreen {
    private List<CricketMatch> liveMatches;

    public void displayLiveMatches() {
        // Display live matches list...
    }

    public void clickOnMatch(CricketMatch match) {
        MatchCoverageScreen coverageScreen = new MatchCoverageScreen(match);
        coverageScreen.startCoverage();
    }
}
