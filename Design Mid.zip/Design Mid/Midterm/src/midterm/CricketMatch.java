/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package midterm;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Asad
 */ 
// CricketMatch class acting as the Subject
 class CricketMatch implements Subject {
    private List<Observer> observers = new ArrayList<>();
    private String matchName;
    private String matchStatus;

    public CricketMatch(String name) {
        this.matchName = name;
    }

    public void setMatchStatus(String status) {
        this.matchStatus = status;
        notifyObservers();
    }

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(matchStatus);
        }
    }
}